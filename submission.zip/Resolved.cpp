#include <iostream>

#include "Resolved.h"

Resolved::Resolved(Issue *issue) : State("Resolved", issue) {}

void Resolved::nextState()
{
    // do nothing
}