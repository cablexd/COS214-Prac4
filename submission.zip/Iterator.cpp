#include "Iterator.h"


//Function 4:
Iterator::~Iterator(){



}