#ifndef ISSUE_H
#define ISSUE_H

#include <vector>
#include <stack>
#include <string>

#include "IssueComponent.h"
#include "Iterator.h"

using namespace std;

class State;

class Issue : public IssueComponent
{
private:
    string name;
    State *state;

    void getSnapshot(vector<IssueComponent *> &snapshot) override;

public:
    Issue(string name);

    IssueBucket *getParentBucket(bool first = true) override;
    IssueComponent *getHandle(bool first = true) override;

    Iterator *createIterator(std::string type) override;

    void setState(State *state);

    // Function 4:
    void print(int level) override;

    // Function 5:
    void execute() override;

    // Functin 6:
    void printState() override;

    std::string getName() override;

    // Function 7:
    virtual ~Issue();
};

#endif
