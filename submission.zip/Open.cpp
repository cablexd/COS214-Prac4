#include <iostream>

#include "Open.h"
#include "InProgress.h"

Open::Open(Issue *issue) : State("Open", issue) {}

void Open::nextState()
{
    issue->setState(new InProgress(issue));
}